import Vue from 'vue'
import VueRouter from 'vue-router'
import LoginView from '../views/LoginView.vue'
import HomeView from '../views/HomeView.vue'
import Register from '../views/Register.vue'
import AdminView from '../views/AdminView.vue'
import RecoverPassword from "@/views/RecoverPassword";
import BrandManage from "@/views/BrandManage";
import AccountView from "@/views/AccountView";
import ModelManage from "@/views/ModelManage";
import BodyStyleManage from "@/views/BodyStyleManage";
import FuelManage from "@/views/FuelManage";
import TransmissionManage from "@/views/TransmissionManage";

Vue.use(VueRouter)

const routes = [
  {
    path: '/login',
    name: 'login',
    component: LoginView
  },
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/register',
    name: 'register',
    component: Register
  },
  {
    path: '/admin',
    name: 'admin',
    component: AdminView
  },
  {
    path: '/recoverpass',
    name: 'recover pass',
    component: RecoverPassword
  },
  {
    path: '/admin/brands',
    name: 'brand manage',
    component: BrandManage
  },
  {
    path: '/account',
    name: 'account',
    component: AccountView
  },
  {
    path: '/admin/models',
    name: 'model manage',
    component: ModelManage
  },
  {
    path: '/admin/bodystyles',
    name: 'body style manage',
    component: BodyStyleManage
  },
  {
    path: '/admin/fuels',
    name: 'fuel manage',
    component: FuelManage
  },
  {
    path: '/admin/transmissions',
    name: 'transmission manage',
    component: TransmissionManage,
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
