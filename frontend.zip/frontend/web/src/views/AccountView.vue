<template>
  <div class="manage-bg">
    <h1 style="color:brown" align="center">
      Detalii cont
    </h1>
    <v-container fill-height>
      <v-row>
        <v-col align="center" justify="center">
          <v-form
              ref="form"
              class="ml-6 mr-6"
          >
            <v-text-field
                v-model="firstName"
                label="Prenume"
                background-color="white"
                outlined
                dense
                rounded
                required
            ></v-text-field>
            <v-text-field
              v-model="lastName"
              label="Nume"
              background-color="white"
              outlined
              dense
              rounded
              required
            ></v-text-field>
            <v-text-field
                v-model="email"
                label="Email"
                background-color="white"
                outlined
                dense
                rounded
                required
            ></v-text-field>
            <v-text-field
                v-model="password"
                label="Parola"
                type="password"
                background-color="white"
                outlined
                dense
                rounded
                required
            ></v-text-field>
            <v-text-field
                v-model="phoneNumber"
                label="Numar de telefon"
                background-color="white"
                outlined
                dense
                rounded
                required
            ></v-text-field>
            <v-text-field
                v-model="address"
                label="Numar de telefon"
                background-color="white"
                outlined
                dense
                rounded
                required
            ></v-text-field>
            <v-btn
              class="ml-6 mr-6"
              color="white"
              rounded
              :style="{color:'brown'}"
              @click="updateUser"
            > Modifica detalii cont
            </v-btn>
            <v-btn
                class="ml-6 mr-6"
                color="white"
                rounded
                :style="{color:'brown'}"
                @click="deleteDialog = true"
            > Sterge cont
            </v-btn>
            <v-dialog
                v-model="deleteDialog"
                max-width="300"
            >
              <v-card>
                <v-card-title class="justify-center">
                  Sigur iti stergi contul?
                  <v-card-actions class="justify-center">
                    <v-btn
                        class="ml-6 mr-6"
                        color="white"
                        rounded
                        :style="{color:'brown'}"
                        @click="deleteUser"
                    > Sterge
                    </v-btn>
                  </v-card-actions>
                </v-card-title>
              </v-card>
            </v-dialog>
          </v-form>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "AccountView",
  data(){
    return{
      currentUser: null,
      firstName: "",
      lastName: "",
      email: "",
      password: "",
      phoneNumber: "",
      address: "",
      deleteDialog: false
    }
  },

  async created(){
    var result = await axios.get("https://localhost:7244/users/" + window.localStorage.getItem("userId"));
    this.currentUser = result.data;
    this.firstName = this.currentUser.firstName;
    this.lastName = this.currentUser.lastName;
    this.email = this.currentUser.email;
    this.password = this.currentUser.password;
    this.phoneNumber = this.currentUser.phoneNumber;
    this.address = this.currentUser.address;
  },

  methods:{
    async updateUser(){
      try{
        await axios.put("https://localhost:7244/users/update", {id: this.currentUser.id,
          firstName: this.firstName, lastName: this.lastName, email: this.email, password: this.password,
          phoneNumber: this.phoneNumber, address: this.address, isAdmin: this.currentUser.isAdmin})
        this.$router.go();
      }
      catch(e){
        alert('Acest email este deja asociat unui cont!')
      }
    },

    async deleteUser(){
      await axios.delete("https://localhost:7244/users/"+this.currentUser.id)
      window.localStorage.setItem("userId", null)
      window.location.href = '/login'
    }
  }
}
</script>