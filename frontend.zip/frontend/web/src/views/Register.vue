<template>
  <v-container fill-height>
    <v-row></v-row>
    <v-row>
      <v-col></v-col>
      <v-col align="center" justify="center"
             :style="{
          backgroundColor: 'black',
          opacity: 0.5
        }">
        <h1 style="color:white">Inregistreaza-te</h1>
        <v-form
            ref="form"
            class="ml-6 mr-6"
        >
          <v-text-field
              class="text-white"
              v-model="firstName"
              label="Prenume"
              background-color=rgb(127,127,127)
              rounded
              required
          ></v-text-field>

          <v-text-field
              class="text-white"
              v-model="lastName"
              label="Nume"
              background-color=rgb(127,127,127)
              rounded
              required
          ></v-text-field>

          <v-text-field
              class="text-white"
              v-model="email"
              label="Email"
              background-color=rgb(127,127,127)
              rounded
              required
          ></v-text-field>

          <v-text-field
              class="text-white"
              v-model="password"
              label="Parola"
              type="password"
              background-color=rgb(127,127,127)
              rounded
              required
          ></v-text-field>

          <v-text-field
              class="text-white"
              v-model="phoneNumber"
              label="Numar de telefon"
              background-color=rgb(127,127,127)
              rounded
              required
          ></v-text-field>

          <v-text-field
              class="text-white"
              v-model="address"
              label="Adresa"
              background-color=rgb(127,127,127)
              rounded
              required
          ></v-text-field>

          <v-btn
              text
              :style="{color:'white'}"
              rounded
              @click="register"
          >
            Sign Up
          </v-btn>

          <v-btn
              text
              :style="{color:'white'}"
              rounded
              @click="$router.push('login');"
          >
            Login
          </v-btn>
        </v-form>
      </v-col>
      <v-col></v-col>
    </v-row>
    <v-row></v-row>

  </v-container>

</template>

<script>
  import axios from "axios";
  export default {
    name: 'Register',
    data() {
      return {
        firstName: "",
        lastName: "",
        email: "",
        password: "",
        phoneNumber: "",
        address: ""
      }
    },
    methods: {
      async register() {
        try { 
          var result = await axios.post("https://localhost:7244/users/register",
              {
                firstName: this.firstName, lastName: this.lastName, email: this.email,
                password: this.password, phoneNumber: this.phoneNumber, address: this.address
              });
          window.localStorage.setItem("userId", result.data.id);
          window.location.href = '/';
        } catch (e) {
          alert("Date incomplete!")
        }
      }
    }
  }
</script>

<style>
.text-white input {
  color: white !important;
}
</style>