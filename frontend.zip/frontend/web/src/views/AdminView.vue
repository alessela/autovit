<template>
  <div class="admin-bg">
    <v-container fill-height>
      <v-row>
        <v-col align="center" justify="center">
          <h1 style="color:white">Administrare site</h1>
          <v-row>
            <v-col>
              <v-btn
                  class="ml-6 mr-6"
                  color="white"
                  :style="{color:'brown'}"
                  rounded
                  @click="$router.push('admin/brands')"
              > Marci
              </v-btn>
            </v-col>
          </v-row>
          <v-spacer></v-spacer>
          <v-row>
            <v-col>
              <v-btn
                  class="ml-6 mr-6"
                  color="white"
                  :style="{color:'brown'}"
                  rounded
                  @click="$router.push('admin/models')"
              > Modele
              </v-btn>
            </v-col>
          </v-row>
          <v-spacer></v-spacer>
          <v-row>
            <v-col>
              <v-btn class="ml-6 mr-6"
                     color="white"
                     :style="{color:'brown'}"
                     rounded
                     @click="$router.push('admin/bodystyles')"
              >Tipuri caroserie</v-btn>
            </v-col>
          </v-row>
          <v-spacer></v-spacer>
          <v-row>
            <v-col>
              <v-btn class="ml-6 mr-6"
                     color="white"
                     :style="{color:'brown'}"
                     rounded
                     @click="$router.push('admin/fuels')"
              >Combustibili
              </v-btn>
            </v-col>
          </v-row>
          <v-spacer></v-spacer>
          <v-row>
            <v-col>
              <v-btn class="ml-6 mr-6"
                     color="white"
                     :style="{color:'brown'}"
                     rounded
                     @click="$router.push('admin/transmissions')"
              >Transmisii
              </v-btn>
            </v-col>
          </v-row>
        </v-col>
        <v-col>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "AdminView",
  data(){
    return{
      currentUser: null
    }
  },

  async created(){
    var result = await axios.get("https://localhost:7244/users/" + window.localStorage.getItem("userId"));
    this.currentUser = result.data;
  },
  methods: {


  }
}
</script>
<style>

</style>
