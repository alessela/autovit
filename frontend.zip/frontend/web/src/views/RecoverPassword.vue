<template>
  <v-container fill-height>
    <v-row>
    </v-row>
    <v-row>
      <v-col>
      </v-col>
      <v-col align="center" justify="center"
             :style="{
          backgroundColor: 'black',
          opacity: 0.5
        }"
      >
        <h1 style="color:white">Introduce o parola noua</h1>

        <v-form
            ref="form"
            class="ml-6 mr-6"
        >
          <v-text-field
              class="text-white"
              background-color=rgb(127,127,127)
              v-model="email"
              label="Email"
              rounded
              required
          ></v-text-field>

          <v-text-field
              class="text-white"
              background-color=rgb(127,127,127)
              v-model="password"
              label="Parola noua"
              type="password"
              rounded
              required
          ></v-text-field>

          <v-btn
              text
              :style="{color:'white'}"
              rounded
              @click="changePassword"
          >
            Schimba parola
          </v-btn>
        </v-form>
      </v-col>
      <v-col>
      </v-col>
    </v-row>
    <v-row>

    </v-row>
  </v-container>
</template>

<script>
import axios from "axios";
export default {
  name: "RecoverPassword",
  data() {
    return {
      email: "",
      password: ""
    }
  },
  methods: {
    encode: function(str){
      return encodeURIComponent(str).replace(/!/g, '%21').replace(/\*/g, '%2A')
          .replace(/\(/g, '%28').replace(/\)/g,'%29').replace(/'/g, '%27');
    },

    async changePassword(){
      try{
        var result = await axios.put("https://localhost:7244/users/changepass?email=" + this.encode(this.email)
            + "&newPassword=" + this.encode(this.password),
            { email: this.email, newPassword: this.password });
        this.$router.push('login')
      }
      catch(e){
        alert("Utilizator inexistent!")
      }
    }
  }
}
</script>