<template>

</template>

<script>
  import axios from "axios";
  export default {
    name: 'Home',
    data() {
      return {
        currentUser: null,
        brands: []
      }
    },

    async created() {
      try {
        var result = await axios.get("https://localhost:7244/users/" + window.localStorage.getItem("userId"));
        this.currentUser = result.data;
        var result2 = await axios.get("https://localhost:7244/brands/list");
        this.brands = result2.data;
      }
      catch (e) {

      }
    },
    methods: {

    }
  }
</script>