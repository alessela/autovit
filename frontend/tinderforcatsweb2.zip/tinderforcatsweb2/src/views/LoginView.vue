<template>
  <v-form
    ref="form"
    class="ml-6 mr-6"
  >
    <v-text-field
      v-model="email"
      label="Email"
      required
    ></v-text-field>

    <v-text-field
      v-model="password"
      label="Password"
      type="password"
      required
    ></v-text-field>

    <v-btn
      color="success"
      class="mr-4"
      @click="login"
    >
      Login
    </v-btn>

    <v-btn
      color="error"
      class="mr-4"
      @click="$router.push({ name: 'register' })"
    >
      Register
    </v-btn>
  </v-form>
</template>

<script>
  import axios from "axios";
  export default {
    name: 'Login',
    data() {
      return {
        email: "",
        password: ""
      }
    },
    methods: {
      encode: function(str){
        return encodeURIComponent(str).replace(/!/g, '%21').replace(/\*/g, '%2A')
            .replace(/\(/g, '%28').replace(/\)/g,'%29').replace(/'/g, '%27');
      },

      async login() {
        try { 
          var result = await axios.post(`https://localhost:7244/users/login?email=${this.encode(this.email)}&password=${this.encode(this.password)}`,
              { email: this.email, password: this.password });
          window.localStorage.setItem("userId", result.data.id);
          this.$router.push({ name: 'home' });
        } catch (e) {
          alert("Credentiale incorecte!");
        }
      }
    }
  }
</script>
