<template>
  <v-form
    ref="form"
    class="ml-6 mr-6"
  >
    <v-text-field
      v-model="firstName"
      label="First Name"
      required
    ></v-text-field>

    <v-text-field
        v-model="lastName"
        label="Last Name"
        required
    ></v-text-field>

    <v-text-field
        v-model="email"
        label="Email"
        required
    ></v-text-field>

    <v-text-field
      v-model="password"
      label="Password"
      type="password"
      required
    ></v-text-field>

    <v-text-field
        v-model="phoneNumber"
        label="Phone Number"
        required
    ></v-text-field>

    <v-text-field
        v-model="address"
        label="Address"
        required
    ></v-text-field>

    <v-btn
      color="success"
      class="mr-4"
      @click="register"
    >
      Register
    </v-btn>

    <v-btn
        color="error"
        class="mr-4"
        @click="$router.push({ name: '..' }); $router.go()"
    >
      Login
    </v-btn>
  </v-form>
</template>

<script>
  import axios from "axios";
  export default {
    name: 'Login',
    data() {
      return {
        firstName: "",
        lastName: "",
        email: "",
        password: "",
        phoneNumber: "",
        address: ""
      }
    },
    methods: {
      async register() {
        try { 
          var result = await axios.post("https://localhost:7244/users/register",
              {
                firstName: this.firstName, lastName: this.lastName, email: this.email,
                password: this.password, phoneNumber: this.phoneNumber, address: this.address
              });
          this.$router.push({ name: 'login' });
        } catch (e) {
          
        }
      }
    }
  }
</script>
