<template>
  <div>
    <h1>
      Welcome to Autovit, {{ currentUser.firstName}} {{currentUser.lastName}}!
    </h1>
    <v-btn
        color="success"
        class="mr-4"
        @click="$router.push({name: '..'}); $router.go();"
    >
      Logout
    </v-btn>
    </div>
</template>

<script>
  import axios from "axios";
  export default {
    name: 'Home',
    data() {
      return {
        currentUser: null
      }
    },
    async created() {
      try {
        var result = await axios.get("https://localhost:7244/users/" + window.localStorage.getItem("userId"));
        this.currentUser = result.data;
      }
      catch (e) {

      }
    },
    methods: {
    }
  }
</script>